const { test, describe, before, after } = require('node:test');
const assert = require('node:assert');
const { startServer, request, login } = require('./helpers');

describe('API integration', () => {
  let ctx;

  before(async () => {
    ctx = await startServer();
  });

  after(async () => {
    await ctx.close();
  });

  describe('POST /api/auth/login', () => {
    test('успішний вхід admin/admin', async () => {
      const r = await request(ctx.base, 'POST', '/api/auth/login', {
        body: { username: 'admin', password: 'admin' },
      });
      assert.equal(r.status, 200);
      assert.ok(r.data.token);
      assert.equal(r.data.user.role, 'admin');
    });

    test('невірний пароль → 401', async () => {
      const r = await request(ctx.base, 'POST', '/api/auth/login', {
        body: { username: 'admin', password: 'wrong' },
      });
      assert.equal(r.status, 401);
    });

    test('відсутні поля → 400', async () => {
      const r = await request(ctx.base, 'POST', '/api/auth/login', { body: {} });
      assert.equal(r.status, 400);
    });

    test('неіснуючий користувач → 401', async () => {
      const r = await request(ctx.base, 'POST', '/api/auth/login', {
        body: { username: 'ghost', password: 'x' },
      });
      assert.equal(r.status, 401);
    });
  });

  describe('GET /api/auth/me', () => {
    test('без токена → 401', async () => {
      const r = await request(ctx.base, 'GET', '/api/auth/me');
      assert.equal(r.status, 401);
    });

    test('з валідним токеном повертає користувача', async () => {
      const token = await login(ctx.base, 'admin', 'admin');
      const r = await request(ctx.base, 'GET', '/api/auth/me', { token });
      assert.equal(r.status, 200);
      assert.equal(r.data.username, 'admin');
      assert.equal(r.data.role, 'admin');
    });
  });

  describe('Tasks CRUD', () => {
    test('повний цикл: create → get → update → delete', async () => {
      const token = await login(ctx.base, 'manager', 'manager');

      const created = await request(ctx.base, 'POST', '/api/tasks', {
        token,
        body: {
          title: 'Інтеграційний тест',
          description: 'опис',
          priority: 'high',
          status: 'todo',
        },
      });
      assert.equal(created.status, 201);
      assert.ok(created.data.id);
      const id = created.data.id;

      const got = await request(ctx.base, 'GET', '/api/tasks/' + id, { token });
      assert.equal(got.status, 200);
      assert.equal(got.data.title, 'Інтеграційний тест');
      assert.equal(got.data.priority, 'high');

      const updated = await request(ctx.base, 'PUT', '/api/tasks/' + id, {
        token,
        body: { status: 'in_progress', title: 'Оновлений' },
      });
      assert.equal(updated.status, 200);
      assert.equal(updated.data.status, 'in_progress');
      assert.equal(updated.data.title, 'Оновлений');

      const history = await request(ctx.base, 'GET', `/api/tasks/${id}/history`, { token });
      assert.equal(history.status, 200);
      assert.ok(history.data.length >= 2);

      const deleted = await request(ctx.base, 'DELETE', '/api/tasks/' + id, { token });
      assert.equal(deleted.status, 200);

      const notFound = await request(ctx.base, 'GET', '/api/tasks/' + id, { token });
      assert.equal(notFound.status, 404);
    });

    test('employee не може створювати завдання → 403', async () => {
      const token = await login(ctx.base, 'employee', 'employee');
      const r = await request(ctx.base, 'POST', '/api/tasks', {
        token,
        body: { title: 'X' },
      });
      assert.equal(r.status, 403);
    });

    test('створення без title → 400', async () => {
      const token = await login(ctx.base, 'admin', 'admin');
      const r = await request(ctx.base, 'POST', '/api/tasks', { token, body: {} });
      assert.equal(r.status, 400);
    });

    test('фільтр за status', async () => {
      const token = await login(ctx.base, 'admin', 'admin');
      const r = await request(ctx.base, 'GET', '/api/tasks?status=done', { token });
      assert.equal(r.status, 200);
      assert.ok(Array.isArray(r.data));
      r.data.forEach(t => assert.equal(t.status, 'done'));
    });

    test('пошук за q', async () => {
      const token = await login(ctx.base, 'admin', 'admin');
      const r = await request(ctx.base, 'GET', '/api/tasks?q=VPN', { token });
      assert.equal(r.status, 200);
      assert.ok(r.data.some(t => /VPN/i.test(t.title)));
    });

    test('GET /tasks/stats повертає коректну структуру', async () => {
      const token = await login(ctx.base, 'admin', 'admin');
      const r = await request(ctx.base, 'GET', '/api/tasks/stats', { token });
      assert.equal(r.status, 200);
      assert.ok(typeof r.data.total === 'number');
      assert.ok(Array.isArray(r.data.byStatus));
      assert.ok(Array.isArray(r.data.byPriority));
      assert.ok(Array.isArray(r.data.timeline));
      assert.equal(r.data.timeline.length, 14);
    });
  });

  describe('Comments', () => {
    test('додавання й отримання коментаря', async () => {
      const token = await login(ctx.base, 'manager', 'manager');
      const taskRes = await request(ctx.base, 'POST', '/api/tasks', {
        token,
        body: { title: 'Для коментарів' },
      });
      const taskId = taskRes.data.id;

      const c = await request(ctx.base, 'POST', `/api/tasks/${taskId}/comments`, {
        token, body: { body: 'Перший коментар' },
      });
      assert.equal(c.status, 201);
      assert.equal(c.data.body, 'Перший коментар');

      const list = await request(ctx.base, 'GET', `/api/tasks/${taskId}/comments`, { token });
      assert.equal(list.status, 200);
      assert.equal(list.data.length, 1);
    });

    test('порожній коментар → 400', async () => {
      const token = await login(ctx.base, 'admin', 'admin');
      const r = await request(ctx.base, 'POST', '/api/tasks/1/comments', {
        token, body: { body: '   ' },
      });
      assert.equal(r.status, 400);
    });
  });

  describe('Users management', () => {
    test('admin може створити користувача', async () => {
      const token = await login(ctx.base, 'admin', 'admin');
      const r = await request(ctx.base, 'POST', '/api/users', {
        token,
        body: {
          username: 'newuser',
          password: 'pass1234',
          full_name: 'Новий Користувач',
          role: 'employee',
          department: 'IT',
        },
      });
      assert.equal(r.status, 201);
      assert.ok(r.data.id);

      const login2 = await request(ctx.base, 'POST', '/api/auth/login', {
        body: { username: 'newuser', password: 'pass1234' },
      });
      assert.equal(login2.status, 200);
    });

    test('manager НЕ може створювати користувачів → 403', async () => {
      const token = await login(ctx.base, 'manager', 'manager');
      const r = await request(ctx.base, 'POST', '/api/users', {
        token,
        body: { username: 'x', password: 'x', full_name: 'x', role: 'employee' },
      });
      assert.equal(r.status, 403);
    });

    test('дублікат логіну → 409', async () => {
      const token = await login(ctx.base, 'admin', 'admin');
      const r = await request(ctx.base, 'POST', '/api/users', {
        token,
        body: { username: 'admin', password: 'x', full_name: 'x', role: 'admin' },
      });
      assert.equal(r.status, 409);
    });

    test('admin не може видалити сам себе → 400', async () => {
      const token = await login(ctx.base, 'admin', 'admin');
      const me = await request(ctx.base, 'GET', '/api/auth/me', { token });
      const r = await request(ctx.base, 'DELETE', '/api/users/' + me.data.id, { token });
      assert.equal(r.status, 400);
    });
  });
});
