const { test, describe } = require('node:test');
const assert = require('node:assert');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

process.env.JWT_SECRET = 'test-secret-key';

const { signToken, JWT_SECRET } = require('../server/auth');

describe('auth utils', () => {
  test('signToken повертає валідний JWT', () => {
    const token = signToken({ id: 1, username: 'admin', role: 'admin' });
    assert.equal(typeof token, 'string');
    const decoded = jwt.verify(token, JWT_SECRET);
    assert.equal(decoded.id, 1);
    assert.equal(decoded.username, 'admin');
    assert.equal(decoded.role, 'admin');
    assert.ok(decoded.exp > decoded.iat);
  });

  test('JWT не валідується з іншим секретом', () => {
    const token = signToken({ id: 1, username: 'x', role: 'admin' });
    assert.throws(() => jwt.verify(token, 'wrong-secret'));
  });

  test('bcrypt hash != пароль і compare працює', () => {
    const pwd = 'mySecret123';
    const hash = bcrypt.hashSync(pwd, 10);
    assert.notEqual(hash, pwd);
    assert.ok(hash.length > 50);
    assert.ok(bcrypt.compareSync(pwd, hash));
    assert.ok(!bcrypt.compareSync('wrong', hash));
  });

  test('різні хеші для одного пароля (через сіль)', () => {
    const pwd = 'samePassword';
    const h1 = bcrypt.hashSync(pwd, 10);
    const h2 = bcrypt.hashSync(pwd, 10);
    assert.notEqual(h1, h2);
  });
});

describe('authMiddleware', () => {
  const { authMiddleware, requireRole } = require('../server/auth');

  function mockReqRes(headers = {}) {
    let statusCode = 200, jsonData = null, nextCalled = false;
    const req = { headers };
    const res = {
      status(c) { statusCode = c; return this; },
      json(d) { jsonData = d; return this; },
    };
    const next = () => { nextCalled = true; };
    return { req, res, next, get status() { return statusCode; }, get data() { return jsonData; }, get nextCalled() { return nextCalled; } };
  }

  test('відхиляє запит без токена', () => {
    const ctx = mockReqRes({});
    authMiddleware(ctx.req, ctx.res, ctx.next);
    assert.equal(ctx.status, 401);
    assert.equal(ctx.nextCalled, false);
  });

  test('відхиляє невалідний токен', () => {
    const ctx = mockReqRes({ authorization: 'Bearer invalid.token.here' });
    authMiddleware(ctx.req, ctx.res, ctx.next);
    assert.equal(ctx.status, 401);
  });

  test('пропускає валідний токен', () => {
    const token = signToken({ id: 5, username: 'u', role: 'manager' });
    const ctx = mockReqRes({ authorization: `Bearer ${token}` });
    authMiddleware(ctx.req, ctx.res, ctx.next);
    assert.equal(ctx.nextCalled, true);
    assert.equal(ctx.req.user.id, 5);
    assert.equal(ctx.req.user.role, 'manager');
  });

  test('requireRole пропускає правильну роль', () => {
    const ctx = mockReqRes();
    ctx.req.user = { id: 1, role: 'admin' };
    requireRole('admin')(ctx.req, ctx.res, ctx.next);
    assert.equal(ctx.nextCalled, true);
  });

  test('requireRole блокує невірну роль', () => {
    const ctx = mockReqRes();
    ctx.req.user = { id: 1, role: 'employee' };
    requireRole('admin', 'manager')(ctx.req, ctx.res, ctx.next);
    assert.equal(ctx.status, 403);
    assert.equal(ctx.nextCalled, false);
  });
});
