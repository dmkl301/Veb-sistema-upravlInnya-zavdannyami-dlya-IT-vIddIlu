const fs = require('fs');
const path = require('path');

process.env.JWT_SECRET = 'test-secret-key';
process.env.NODE_ENV = 'test';

function freshDb() {
  const dataDir = path.join(__dirname, '..', 'data');
  const dbFile = path.join(dataDir, 'app.sqlite');
  if (fs.existsSync(dbFile)) fs.rmSync(dbFile);
  const wal = dbFile + '-wal';
  const shm = dbFile + '-shm';
  if (fs.existsSync(wal)) fs.rmSync(wal);
  if (fs.existsSync(shm)) fs.rmSync(shm);
  Object.keys(require.cache).forEach(k => {
    if (k.includes(path.sep + 'server' + path.sep) || k.includes('better-sqlite3')) {
      delete require.cache[k];
    }
  });
}

function startServer() {
  freshDb();
  const express = require('express');
  require('../server/db');
  const authRoutes = require('../server/routes/auth');
  const userRoutes = require('../server/routes/users');
  const taskRoutes = require('../server/routes/tasks');
  const commentRoutes = require('../server/routes/comments');

  const app = express();
  app.use(express.json());
  app.use('/api/auth', authRoutes);
  app.use('/api/users', userRoutes);
  app.use('/api/tasks', taskRoutes);
  app.use('/api/tasks', commentRoutes);

  return new Promise((resolve) => {
    const srv = app.listen(0, () => {
      const port = srv.address().port;
      resolve({
        srv,
        port,
        base: `http://127.0.0.1:${port}`,
        close: () => new Promise(r => srv.close(r)),
      });
    });
  });
}

async function request(base, method, url, { token, body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(base + url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch {}
  return { status: res.status, data };
}

async function login(base, username, password) {
  const r = await request(base, 'POST', '/api/auth/login', { body: { username, password } });
  if (r.status !== 200) throw new Error(`login failed: ${r.status} ${JSON.stringify(r.data)}`);
  return r.data.token;
}

module.exports = { freshDb, startServer, request, login };
