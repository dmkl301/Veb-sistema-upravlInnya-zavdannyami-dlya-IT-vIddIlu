const express = require('express');
const path = require('path');
require('./db');

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const taskRoutes = require('./routes/tasks');
const commentRoutes = require('./routes/comments');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/tasks', commentRoutes);

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Внутрішня помилка сервера' });
});

app.listen(PORT, () => {
  console.log(`\n🚀 IT Task Manager запущено на http://localhost:${PORT}\n`);
  console.log('Тестові акаунти:');
  console.log('  admin / admin       — адміністратор');
  console.log('  manager / manager   — менеджер');
  console.log('  employee / employee — виконавець');
  console.log('  anna / anna123      — виконавець\n');
});
