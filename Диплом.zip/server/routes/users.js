const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { authMiddleware, requireRole } = require('../auth');

const router = express.Router();

router.use(authMiddleware);

router.get('/', (req, res) => {
  const users = db.prepare(
    'SELECT id, username, full_name, role, department, created_at FROM users ORDER BY full_name'
  ).all();
  res.json(users);
});

router.post('/', requireRole('admin'), (req, res) => {
  const { username, password, full_name, role, department } = req.body || {};
  if (!username || !password || !full_name || !role) {
    return res.status(400).json({ error: 'Заповніть усі обов\'язкові поля' });
  }
  if (!['admin', 'manager', 'employee'].includes(role)) {
    return res.status(400).json({ error: 'Невірна роль' });
  }
  const exists = db.prepare('SELECT 1 FROM users WHERE username = ?').get(username);
  if (exists) return res.status(409).json({ error: 'Логін вже зайнятий' });
  const hash = bcrypt.hashSync(password, 10);
  const result = db.prepare(
    'INSERT INTO users (username, password_hash, full_name, role, department) VALUES (?, ?, ?, ?, ?)'
  ).run(username, hash, full_name, role, department || null);
  res.status(201).json({ id: result.lastInsertRowid });
});

router.put('/:id', requireRole('admin'), (req, res) => {
  const { full_name, role, department, password } = req.body || {};
  const id = Number(req.params.id);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!user) return res.status(404).json({ error: 'Користувача не знайдено' });
  if (role && !['admin', 'manager', 'employee'].includes(role)) {
    return res.status(400).json({ error: 'Невірна роль' });
  }
  const updates = [];
  const params = [];
  if (full_name) { updates.push('full_name = ?'); params.push(full_name); }
  if (role) { updates.push('role = ?'); params.push(role); }
  if (department !== undefined) { updates.push('department = ?'); params.push(department); }
  if (password) { updates.push('password_hash = ?'); params.push(bcrypt.hashSync(password, 10)); }
  if (!updates.length) return res.json({ ok: true });
  params.push(id);
  db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  res.json({ ok: true });
});

router.delete('/:id', requireRole('admin'), (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) return res.status(400).json({ error: 'Не можна видалити себе' });
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  res.json({ ok: true });
});

module.exports = router;
