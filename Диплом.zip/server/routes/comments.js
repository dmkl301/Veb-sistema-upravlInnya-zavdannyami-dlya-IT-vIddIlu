const express = require('express');
const db = require('../db');
const { authMiddleware } = require('../auth');

const router = express.Router({ mergeParams: true });
router.use(authMiddleware);

router.get('/:taskId/comments', (req, res) => {
  const taskId = Number(req.params.taskId);
  const items = db.prepare(`
    SELECT c.*, u.full_name AS user_name, u.username
    FROM comments c
    LEFT JOIN users u ON u.id = c.user_id
    WHERE c.task_id = ?
    ORDER BY c.created_at ASC
  `).all(taskId);
  res.json(items);
});

router.post('/:taskId/comments', (req, res) => {
  const taskId = Number(req.params.taskId);
  const { body } = req.body || {};
  if (!body || !body.trim()) return res.status(400).json({ error: 'Коментар не може бути порожнім' });
  const task = db.prepare('SELECT id FROM tasks WHERE id = ?').get(taskId);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  const result = db.prepare(
    'INSERT INTO comments (task_id, user_id, body) VALUES (?, ?, ?)'
  ).run(taskId, req.user.id, body.trim());
  db.prepare(
    'INSERT INTO task_history (task_id, user_id, action, details) VALUES (?, ?, ?, ?)'
  ).run(taskId, req.user.id, 'commented', body.trim().slice(0, 100));
  const created = db.prepare(`
    SELECT c.*, u.full_name AS user_name, u.username
    FROM comments c LEFT JOIN users u ON u.id = c.user_id
    WHERE c.id = ?
  `).get(result.lastInsertRowid);
  res.status(201).json(created);
});

router.delete('/:taskId/comments/:commentId', (req, res) => {
  const commentId = Number(req.params.commentId);
  const c = db.prepare('SELECT * FROM comments WHERE id = ?').get(commentId);
  if (!c) return res.status(404).json({ error: 'Коментар не знайдено' });
  if (c.user_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Можна видаляти лише свої коментарі' });
  }
  db.prepare('DELETE FROM comments WHERE id = ?').run(commentId);
  res.json({ ok: true });
});

module.exports = router;
