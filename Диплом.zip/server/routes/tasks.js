const express = require('express');
const db = require('../db');
const { authMiddleware, requireRole } = require('../auth');

const router = express.Router();
router.use(authMiddleware);

const VALID_STATUS = ['todo', 'in_progress', 'review', 'done'];
const VALID_PRIORITY = ['low', 'medium', 'high', 'critical'];

function logHistory(taskId, userId, action, details = null) {
  db.prepare(
    'INSERT INTO task_history (task_id, user_id, action, details) VALUES (?, ?, ?, ?)'
  ).run(taskId, userId, action, details);
}

function selectTaskById(id) {
  return db.prepare(`
    SELECT t.*,
           a.full_name AS author_name,
           u.full_name AS assignee_name
    FROM tasks t
    LEFT JOIN users a ON a.id = t.author_id
    LEFT JOIN users u ON u.id = t.assignee_id
    WHERE t.id = ?
  `).get(id);
}

router.get('/', (req, res) => {
  const { status, priority, assignee_id, author_id, q, mine } = req.query;
  const where = [];
  const params = [];

  if (status) { where.push('t.status = ?'); params.push(status); }
  if (priority) { where.push('t.priority = ?'); params.push(priority); }
  if (assignee_id) { where.push('t.assignee_id = ?'); params.push(Number(assignee_id)); }
  if (author_id) { where.push('t.author_id = ?'); params.push(Number(author_id)); }
  if (mine === '1') { where.push('t.assignee_id = ?'); params.push(req.user.id); }
  if (q) {
    where.push('(t.title LIKE ? OR t.description LIKE ? OR t.tags LIKE ?)');
    const like = `%${q}%`;
    params.push(like, like, like);
  }

  const sql = `
    SELECT t.*,
           a.full_name AS author_name,
           u.full_name AS assignee_name,
           u.username  AS assignee_username,
           (SELECT COUNT(*) FROM comments c WHERE c.task_id = t.id) AS comment_count
    FROM tasks t
    LEFT JOIN users a ON a.id = t.author_id
    LEFT JOIN users u ON u.id = t.assignee_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY
      CASE t.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,
      t.deadline IS NULL, t.deadline ASC, t.created_at DESC
  `;
  res.json(db.prepare(sql).all(...params));
});

router.get('/stats', (req, res) => {
  const byStatus = db.prepare('SELECT status, COUNT(*) AS c FROM tasks GROUP BY status').all();
  const byPriority = db.prepare('SELECT priority, COUNT(*) AS c FROM tasks GROUP BY priority').all();
  const overdue = db.prepare(
    `SELECT COUNT(*) AS c FROM tasks WHERE status != 'done' AND deadline IS NOT NULL AND deadline < date('now')`
  ).get().c;
  const myOpen = db.prepare(
    `SELECT COUNT(*) AS c FROM tasks WHERE assignee_id = ? AND status != 'done'`
  ).get(req.user.id).c;
  const total = db.prepare('SELECT COUNT(*) AS c FROM tasks').get().c;

  const byAssignee = db.prepare(`
    SELECT u.full_name AS name,
           SUM(CASE WHEN t.status != 'done' THEN 1 ELSE 0 END) AS open_count,
           SUM(CASE WHEN t.status = 'done' THEN 1 ELSE 0 END) AS done_count
    FROM users u LEFT JOIN tasks t ON t.assignee_id = u.id
    GROUP BY u.id
    HAVING open_count > 0 OR done_count > 0
    ORDER BY (open_count + done_count) DESC
    LIMIT 10
  `).all();

  const timeline = db.prepare(`
    WITH RECURSIVE dates(d) AS (
      SELECT date('now', '-13 days')
      UNION ALL SELECT date(d, '+1 day') FROM dates WHERE d < date('now')
    )
    SELECT dates.d AS date,
           COUNT(t.id) AS created,
           SUM(CASE WHEN t.status = 'done' THEN 1 ELSE 0 END) AS done
    FROM dates LEFT JOIN tasks t ON date(t.created_at) = dates.d
    GROUP BY dates.d ORDER BY dates.d
  `).all();

  res.json({ byStatus, byPriority, overdue, myOpen, total, byAssignee, timeline });
});

router.get('/:id', (req, res) => {
  const task = selectTaskById(Number(req.params.id));
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  res.json(task);
});

router.post('/', requireRole('admin', 'manager'), (req, res) => {
  const { title, description, status, priority, deadline, tags, assignee_id } = req.body || {};
  if (!title) return res.status(400).json({ error: 'Введіть назву завдання' });
  const st = status && VALID_STATUS.includes(status) ? status : 'todo';
  const pr = priority && VALID_PRIORITY.includes(priority) ? priority : 'medium';
  const result = db.prepare(
    `INSERT INTO tasks (title, description, status, priority, deadline, tags, author_id, assignee_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    title,
    description || null,
    st,
    pr,
    deadline || null,
    tags || null,
    req.user.id,
    assignee_id ? Number(assignee_id) : null
  );
  logHistory(result.lastInsertRowid, req.user.id, 'created', `Створено завдання "${title}"`);
  res.status(201).json(selectTaskById(result.lastInsertRowid));
});

router.put('/:id', (req, res) => {
  const id = Number(req.params.id);
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });

  const isAuthor = task.author_id === req.user.id;
  const isAssignee = task.assignee_id === req.user.id;
  const isPrivileged = ['admin', 'manager'].includes(req.user.role);
  if (!isPrivileged && !isAuthor && !isAssignee) {
    return res.status(403).json({ error: 'Немає прав на редагування' });
  }

  const { title, description, status, priority, deadline, tags, assignee_id } = req.body || {};
  const updates = [];
  const params = [];
  const changes = [];

  if (title !== undefined && title !== task.title) {
    updates.push('title = ?'); params.push(title);
    changes.push(`назва: "${task.title}" → "${title}"`);
  }
  if (description !== undefined && description !== task.description) {
    updates.push('description = ?'); params.push(description);
    changes.push('опис змінено');
  }
  if (status !== undefined && status !== task.status) {
    if (!VALID_STATUS.includes(status)) return res.status(400).json({ error: 'Невірний статус' });
    updates.push('status = ?'); params.push(status);
    changes.push(`статус: ${task.status} → ${status}`);
  }
  if (priority !== undefined && priority !== task.priority) {
    if (!VALID_PRIORITY.includes(priority)) return res.status(400).json({ error: 'Невірний пріоритет' });
    if (!isPrivileged && !isAuthor) return res.status(403).json({ error: 'Тільки автор/менеджер може змінювати пріоритет' });
    updates.push('priority = ?'); params.push(priority);
    changes.push(`пріоритет: ${task.priority} → ${priority}`);
  }
  if (deadline !== undefined && deadline !== task.deadline) {
    if (!isPrivileged && !isAuthor) return res.status(403).json({ error: 'Тільки автор/менеджер може змінювати дедлайн' });
    updates.push('deadline = ?'); params.push(deadline || null);
    changes.push(`дедлайн: ${task.deadline || '—'} → ${deadline || '—'}`);
  }
  if (tags !== undefined && tags !== task.tags) {
    updates.push('tags = ?'); params.push(tags);
    changes.push('теги оновлено');
  }
  if (assignee_id !== undefined && Number(assignee_id) !== task.assignee_id) {
    if (!isPrivileged && !isAuthor) return res.status(403).json({ error: 'Тільки автор/менеджер може призначати виконавця' });
    updates.push('assignee_id = ?'); params.push(assignee_id ? Number(assignee_id) : null);
    changes.push('виконавця змінено');
  }

  if (!updates.length) return res.json(selectTaskById(id));

  updates.push("updated_at = datetime('now')");
  params.push(id);
  db.prepare(`UPDATE tasks SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  logHistory(id, req.user.id, 'updated', changes.join('; '));
  res.json(selectTaskById(id));
});

router.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
  if (!task) return res.status(404).json({ error: 'Завдання не знайдено' });
  const isAuthor = task.author_id === req.user.id;
  if (!isAuthor && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Тільки автор або адміністратор може видаляти' });
  }
  db.prepare('DELETE FROM tasks WHERE id = ?').run(id);
  res.json({ ok: true });
});

router.get('/:id/history', (req, res) => {
  const id = Number(req.params.id);
  const items = db.prepare(`
    SELECT h.*, u.full_name AS user_name
    FROM task_history h
    LEFT JOIN users u ON u.id = h.user_id
    WHERE h.task_id = ?
    ORDER BY h.created_at DESC
  `).all(id);
  res.json(items);
});

module.exports = router;
