const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, 'app.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin','manager','employee')),
    department TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'todo' CHECK(status IN ('todo','in_progress','review','done')),
    priority TEXT NOT NULL DEFAULT 'medium' CHECK(priority IN ('low','medium','high','critical')),
    deadline TEXT,
    tags TEXT,
    author_id INTEGER NOT NULL,
    assignee_id INTEGER,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(author_id) REFERENCES users(id),
    FOREIGN KEY(assignee_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS task_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    details TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE INDEX IF NOT EXISTS idx_tasks_assignee ON tasks(assignee_id);
  CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
  CREATE INDEX IF NOT EXISTS idx_comments_task ON comments(task_id);
  CREATE INDEX IF NOT EXISTS idx_history_task ON task_history(task_id);
`);

const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
if (userCount === 0) {
  const insertUser = db.prepare(
    'INSERT INTO users (username, password_hash, full_name, role, department) VALUES (?, ?, ?, ?, ?)'
  );
  const hash = (pwd) => bcrypt.hashSync(pwd, 10);
  insertUser.run('admin', hash('admin'), 'Адміністратор Системи', 'admin', 'IT');
  insertUser.run('manager', hash('manager'), 'Олег Менеджер', 'manager', 'IT');
  insertUser.run('employee', hash('employee'), 'Іван Виконавець', 'employee', 'IT');
  insertUser.run('anna', hash('anna123'), 'Анна Петрова', 'employee', 'IT');

  const insertTask = db.prepare(
    `INSERT INTO tasks (title, description, status, priority, deadline, tags, author_id, assignee_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  insertTask.run('Налаштувати VPN на новому ноутбуці', 'Підключити нового співробітника до корпоративного VPN', 'todo', 'high', '2026-05-10', 'vpn,setup', 2, 3);
  insertTask.run('Оновити антивірусне ПЗ', 'Оновлення на всіх робочих станціях відділу бухгалтерії', 'in_progress', 'medium', '2026-05-15', 'security,update', 2, 4);
  insertTask.run('Замінити картридж у принтері', 'Принтер HP LaserJet у кабінеті 305', 'todo', 'low', '2026-05-05', 'hardware', 2, 3);
  insertTask.run('Резервне копіювання БД', 'Налаштувати щоденне резервне копіювання', 'review', 'critical', '2026-05-08', 'backup,db', 1, 4);
  insertTask.run('Інтеграція 1С з CRM', 'Перевірити коректність синхронізації даних', 'done', 'high', '2026-04-20', 'integration', 2, 3);
}

module.exports = db;
