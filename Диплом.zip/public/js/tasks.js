const tasksView = {
  filters: { q: '', status: '', priority: '', assignee_id: '', mine: '' },
  users: [],

  async render(root) {
    root.innerHTML = '<div class="empty">Завантаження…</div>';
    try {
      this.users = await api.get('/users');
    } catch {}
    root.innerHTML = '';
    root.append(this.buildHeader(), this.buildFilters());
    const listEl = ui.el('div', { id: 'tasks-list-root' });
    root.append(listEl);
    await this.refresh();
  },

  buildHeader() {
    const me = JSON.parse(localStorage.getItem('user') || '{}');
    const canCreate = me.role === 'admin' || me.role === 'manager';
    const actions = ui.el('div', { class: 'view-actions' });
    if (canCreate) {
      actions.append(ui.el('button', {
        class: 'btn btn-primary',
        onclick: () => this.openTaskForm(),
      }, '+ Нове завдання'));
    }
    return ui.el('div', { class: 'view-header' }, [
      ui.el('h2', {}, 'Завдання'),
      actions,
    ]);
  },

  buildFilters() {
    const f = ui.el('div', { class: 'filters' });
    const search = ui.el('input', {
      type: 'search',
      placeholder: 'Пошук за назвою, описом, тегами…',
      oninput: (e) => { this.filters.q = e.target.value; this.refresh(); },
    });
    const statusSel = this.makeSelect(['', ...Object.keys(ui.STATUS_LABELS)],
      v => v ? ui.STATUS_LABELS[v] : 'Всі статуси',
      v => { this.filters.status = v; this.refresh(); });
    const prioSel = this.makeSelect(['', ...Object.keys(ui.PRIORITY_LABELS)],
      v => v ? ui.PRIORITY_LABELS[v] : 'Всі пріоритети',
      v => { this.filters.priority = v; this.refresh(); });
    const assigneeSel = ui.el('select', {
      onchange: (e) => { this.filters.assignee_id = e.target.value; this.refresh(); }
    });
    assigneeSel.append(ui.el('option', { value: '' }, 'Всі виконавці'));
    this.users.forEach(u => assigneeSel.append(ui.el('option', { value: u.id }, u.full_name)));

    const mineBtn = ui.el('button', {
      class: 'btn btn-ghost',
      onclick: () => {
        this.filters.mine = this.filters.mine ? '' : '1';
        mineBtn.classList.toggle('btn-primary');
        mineBtn.classList.toggle('btn-ghost');
        this.refresh();
      },
    }, 'Тільки мої');

    f.append(search, statusSel, prioSel, assigneeSel, mineBtn);
    return f;
  },

  makeSelect(values, labelFn, onChange) {
    const sel = ui.el('select', { onchange: (e) => onChange(e.target.value) });
    values.forEach(v => sel.append(ui.el('option', { value: v }, labelFn(v))));
    return sel;
  },

  async refresh() {
    const root = document.getElementById('tasks-list-root');
    if (!root) return;
    const params = new URLSearchParams();
    Object.entries(this.filters).forEach(([k, v]) => { if (v) params.set(k, v); });
    try {
      const tasks = await api.get('/tasks?' + params.toString());
      root.innerHTML = '';
      if (!tasks.length) {
        root.append(ui.el('div', { class: 'empty empty-state' }, [
          ui.el('div', { class: 'empty-icon' }, '📭'),
          ui.el('div', {}, 'Завдань не знайдено'),
          ui.el('div', { class: 'empty-hint' }, 'Спробуйте змінити фільтри'),
        ]));
        return;
      }
      const counter = ui.el('div', { class: 'tasks-counter' }, `Знайдено: ${tasks.length}`);
      const grid = ui.el('div', { class: 'tasks-grid' });
      tasks.forEach(t => grid.append(this.taskCard(t)));
      root.append(counter, grid);
    } catch (e) {
      root.innerHTML = `<div class="empty">${e.message}</div>`;
    }
  },

  taskRow(t) {
    return this.taskCard(t);
  },

  taskCard(t) {
    const overdue = ui.isOverdue(t.deadline, t.status);
    const tags = (t.tags || '').split(',').map(s => s.trim()).filter(Boolean);

    const head = ui.el('div', { class: 'tc-head' }, [
      ui.el('span', { class: `priority-dot priority-${t.priority}`, title: ui.PRIORITY_LABELS[t.priority] }),
      ui.el('span', { class: 'tc-id' }, `#${t.id}`),
      ui.badge('status', t.status),
    ]);

    const title = ui.el('div', { class: 'tc-title' }, t.title);

    const desc = t.description
      ? ui.el('div', { class: 'tc-desc' }, t.description.length > 90 ? t.description.slice(0, 90) + '…' : t.description)
      : null;

    const tagBox = tags.length
      ? ui.el('div', { class: 'tc-tags' }, tags.map(tag => ui.el('span', { class: 'tc-tag' }, '#' + tag)))
      : null;

    const footer = ui.el('div', { class: 'tc-footer' }, [
      ui.el('div', { class: 'tc-assignee' }, [
        ui.avatar(t.assignee_name, 26),
        ui.el('span', { class: 'tc-assignee-name' }, t.assignee_name || 'Не призначено'),
      ]),
      ui.el('div', { class: 'tc-meta' }, [
        t.comment_count ? ui.el('span', { class: 'tc-icon', title: 'Коментарі' }, `💬 ${t.comment_count}`) : null,
        t.deadline ? ui.el('span', {
          class: 'tc-deadline' + (overdue ? ' overdue' : ''),
          title: ui.formatDate(t.deadline),
        }, '📅 ' + ui.deadlineLabel(t.deadline, t.status)) : null,
      ]),
    ]);

    return ui.el('div', {
      class: `task-card priority-border-${t.priority} status-bg-${t.status}` + (overdue ? ' is-overdue' : ''),
      onclick: () => this.openTaskDetail(t.id),
    }, [head, title, desc, tagBox, footer]);
  },

  async openTaskDetail(id) {
    let task, comments, history;
    try {
      [task, comments, history] = await Promise.all([
        api.get('/tasks/' + id),
        api.get(`/tasks/${id}/comments`),
        api.get(`/tasks/${id}/history`),
      ]);
    } catch (e) { ui.toast(e.message, 'error'); return; }

    const me = JSON.parse(localStorage.getItem('user') || '{}');
    const canEdit = me.role === 'admin' || me.role === 'manager' || task.author_id === me.id || task.assignee_id === me.id;
    const canDelete = me.role === 'admin' || task.author_id === me.id;

    const body = ui.el('div');
    body.append(this.buildDetail(task, canEdit));
    body.append(this.buildComments(task.id, comments));
    body.append(this.buildHistory(history));

    const footer = [];
    if (canEdit) {
      footer.push(ui.el('button', {
        class: 'btn btn-ghost',
        onclick: () => { modal.close(); this.openTaskForm(task); },
      }, 'Редагувати'));
    }
    if (canDelete) {
      footer.push(ui.el('button', {
        class: 'btn btn-danger',
        onclick: async () => {
          if (!confirm('Видалити завдання?')) return;
          try {
            await api.del('/tasks/' + task.id);
            ui.toast('Завдання видалено', 'success');
            modal.close();
            this.refresh();
          } catch (e) { ui.toast(e.message, 'error'); }
        },
      }, 'Видалити'));
    }
    footer.push(ui.el('button', { class: 'btn btn-primary', onclick: () => modal.close() }, 'Закрити'));

    const modal = ui.modal({ title: `Завдання #${task.id}`, body, footer });
  },

  buildDetail(t, canEdit) {
    const wrap = ui.el('div');
    wrap.append(ui.el('h3', { style: 'margin-bottom: 8px' }, t.title));
    if (t.description) wrap.append(ui.el('p', { style: 'margin-bottom: 16px; white-space: pre-wrap' }, t.description));

    const me = JSON.parse(localStorage.getItem('user') || '{}');
    const grid = ui.el('div', { class: 'detail-grid' }, [
      this.detailItem('Статус', () => {
        if (!canEdit) return ui.badge('status', t.status);
        const sel = ui.el('select', {
          onchange: async (e) => {
            try {
              await api.put('/tasks/' + t.id, { status: e.target.value });
              ui.toast('Статус оновлено', 'success');
              this.refresh();
            } catch (err) { ui.toast(err.message, 'error'); }
          },
        });
        Object.entries(ui.STATUS_LABELS).forEach(([v, l]) => {
          const opt = ui.el('option', { value: v }, l);
          if (v === t.status) opt.selected = true;
          sel.append(opt);
        });
        return sel;
      }),
      this.detailItem('Пріоритет', () => ui.badge('priority', t.priority)),
      this.detailItem('Дедлайн', () => {
        const overdue = ui.isOverdue(t.deadline, t.status);
        return ui.el('span', { class: overdue ? 'deadline overdue' : 'deadline' }, ui.formatDate(t.deadline));
      }),
      this.detailItem('Автор', () => t.author_name || '—'),
      this.detailItem('Виконавець', () => t.assignee_name || '—'),
      this.detailItem('Теги', () => t.tags || '—'),
      this.detailItem('Створено', () => ui.formatDateTime(t.created_at)),
      this.detailItem('Оновлено', () => ui.formatDateTime(t.updated_at)),
    ]);
    wrap.append(grid);
    return wrap;
  },

  detailItem(label, valueFn) {
    const item = ui.el('div', { class: 'detail-item' });
    item.append(ui.el('div', { class: 'lbl' }, label));
    const v = valueFn();
    item.append(ui.el('div', { class: 'val' }, v && v.nodeType ? [v] : v));
    return item;
  },

  buildComments(taskId, comments) {
    const wrap = ui.el('div', { class: 'task-detail-section' });
    wrap.append(ui.el('h4', {}, `Коментарі (${comments.length})`));
    const list = ui.el('div', { class: 'comments-list' });
    if (!comments.length) list.append(ui.el('div', { class: 'empty', style: 'padding:12px' }, 'Поки що немає коментарів'));
    comments.forEach(c => {
      list.append(ui.el('div', { class: 'comment' }, [
        ui.el('div', { class: 'comment-head' }, [
          ui.el('span', { class: 'comment-author' }, c.user_name || c.username),
          ui.el('span', { class: 'comment-time' }, ui.formatDateTime(c.created_at)),
        ]),
        ui.el('div', {}, c.body),
      ]));
    });
    wrap.append(list);

    const form = ui.el('form', {
      style: 'display:flex; gap:8px',
      onsubmit: async (e) => {
        e.preventDefault();
        const input = form.querySelector('textarea');
        const body = input.value.trim();
        if (!body) return;
        try {
          await api.post(`/tasks/${taskId}/comments`, { body });
          input.value = '';
          this.openTaskDetail(taskId);
        } catch (err) { ui.toast(err.message, 'error'); }
      },
    });
    const ta = ui.el('textarea', { rows: 2, placeholder: 'Додати коментар…' });
    const btn = ui.el('button', { type: 'submit', class: 'btn btn-primary' }, 'Надіслати');
    form.append(ta, btn);
    wrap.append(form);
    return wrap;
  },

  buildHistory(history) {
    const wrap = ui.el('div', { class: 'task-detail-section' });
    wrap.append(ui.el('h4', {}, 'Історія'));
    if (!history.length) {
      wrap.append(ui.el('div', { class: 'empty', style: 'padding:8px' }, 'Записів немає'));
      return wrap;
    }
    const list = ui.el('div', { class: 'history-list' });
    history.forEach(h => {
      list.append(ui.el('div', { class: 'history-item' }, [
        ui.el('span', { class: 'who' }, h.user_name || '—'),
        ui.el('span', {}, ` ${this.actionLabel(h.action)}: ${h.details || ''}`),
        ui.el('span', { class: 'when' }, ui.formatDateTime(h.created_at)),
      ]));
    });
    wrap.append(list);
    return wrap;
  },

  actionLabel(a) {
    return ({ created: 'створив', updated: 'оновив', commented: 'прокоментував' })[a] || a;
  },

  openTaskForm(task = null) {
    const isEdit = !!task;
    const f = ui.el('form');
    const fields = {
      title: ui.el('input', { type: 'text', name: 'title', required: true, value: task?.title || '' }),
      description: ui.el('textarea', { name: 'description', rows: 4 }, task?.description || ''),
      status: ui.el('select', { name: 'status' }),
      priority: ui.el('select', { name: 'priority' }),
      deadline: ui.el('input', { type: 'date', name: 'deadline', value: task?.deadline || '' }),
      tags: ui.el('input', { type: 'text', name: 'tags', placeholder: 'tag1,tag2', value: task?.tags || '' }),
      assignee_id: ui.el('select', { name: 'assignee_id' }),
    };
    Object.entries(ui.STATUS_LABELS).forEach(([v, l]) => {
      const o = ui.el('option', { value: v }, l);
      if (task && task.status === v) o.selected = true;
      fields.status.append(o);
    });
    Object.entries(ui.PRIORITY_LABELS).forEach(([v, l]) => {
      const o = ui.el('option', { value: v }, l);
      if (task ? task.priority === v : v === 'medium') o.selected = true;
      fields.priority.append(o);
    });
    fields.assignee_id.append(ui.el('option', { value: '' }, '— не призначено —'));
    this.users.forEach(u => {
      const o = ui.el('option', { value: u.id }, `${u.full_name} (${ui.ROLE_LABELS[u.role]})`);
      if (task && task.assignee_id === u.id) o.selected = true;
      fields.assignee_id.append(o);
    });

    f.append(
      ui.el('label', {}, [ui.el('span', {}, 'Назва *'), fields.title]),
      ui.el('label', {}, [ui.el('span', {}, 'Опис'), fields.description]),
      ui.el('div', { class: 'row' }, [
        ui.el('label', {}, [ui.el('span', {}, 'Статус'), fields.status]),
        ui.el('label', {}, [ui.el('span', {}, 'Пріоритет'), fields.priority]),
      ]),
      ui.el('div', { class: 'row' }, [
        ui.el('label', {}, [ui.el('span', {}, 'Дедлайн'), fields.deadline]),
        ui.el('label', {}, [ui.el('span', {}, 'Теги'), fields.tags]),
      ]),
      ui.el('label', {}, [ui.el('span', {}, 'Виконавець'), fields.assignee_id]),
    );

    const submit = ui.el('button', { type: 'submit', class: 'btn btn-primary' }, isEdit ? 'Зберегти' : 'Створити');
    const cancel = ui.el('button', { type: 'button', class: 'btn btn-ghost', onclick: () => modal.close() }, 'Скасувати');

    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(f));
      if (data.assignee_id === '') data.assignee_id = null;
      if (data.deadline === '') data.deadline = null;
      try {
        if (isEdit) {
          await api.put('/tasks/' + task.id, data);
          ui.toast('Завдання оновлено', 'success');
        } else {
          await api.post('/tasks', data);
          ui.toast('Завдання створено', 'success');
        }
        modal.close();
        this.refresh();
      } catch (err) { ui.toast(err.message, 'error'); }
    });

    const modal = ui.modal({
      title: isEdit ? 'Редагування завдання' : 'Нове завдання',
      body: f,
      footer: [cancel, submit],
    });
  },
};
