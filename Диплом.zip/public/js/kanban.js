const kanbanView = {
  COLS: ['todo', 'in_progress', 'review', 'done'],
  COL_ICONS: { todo: '📋', in_progress: '⚙️', review: '👀', done: '✅' },

  async render(root) {
    root.innerHTML = '<div class="empty">Завантаження…</div>';
    try {
      const [tasks, users] = await Promise.all([
        api.get('/tasks'),
        api.get('/users').catch(() => []),
      ]);
      tasksView.users = users;
      root.innerHTML = '';
      const me = JSON.parse(localStorage.getItem('user') || '{}');
      const canCreate = me.role === 'admin' || me.role === 'manager';

      root.append(
        ui.el('div', { class: 'view-header' }, [
          ui.el('h2', {}, '🗂 Канбан-дошка'),
          ui.el('div', { class: 'view-actions' }, [
            canCreate ? ui.el('button', {
              class: 'btn btn-primary',
              onclick: () => tasksView.openTaskForm(),
            }, '+ Нове завдання') : null,
            ui.el('button', {
              class: 'btn btn-ghost',
              onclick: () => this.render(root),
            }, '↻ Оновити'),
          ]),
        ])
      );
      const board = ui.el('div', { class: 'kanban' });
      this.COLS.forEach(status =>
        board.append(this.column(status, tasks.filter(t => t.status === status), canCreate))
      );
      root.append(board);
    } catch (e) {
      root.innerHTML = `<div class="empty">${e.message}</div>`;
    }
  },

  column(status, tasks, canCreate) {
    const col = ui.el('div', {
      class: `kanban-col col-${status}`,
      dataset: { status },
      ondragover: (e) => { e.preventDefault(); col.classList.add('drag-over'); },
      ondragleave: () => col.classList.remove('drag-over'),
      ondrop: async (e) => {
        e.preventDefault();
        col.classList.remove('drag-over');
        const id = e.dataTransfer.getData('task-id');
        if (!id) return;
        try {
          await api.put('/tasks/' + id, { status });
          ui.toast('Статус оновлено', 'success');
          this.render(document.getElementById('view-root'));
        } catch (err) { ui.toast(err.message, 'error'); }
      },
    });

    const head = ui.el('div', { class: 'kanban-head' }, [
      ui.el('div', { class: 'kanban-head-title' }, [
        ui.el('span', { class: 'kanban-head-icon' }, this.COL_ICONS[status]),
        ui.el('span', {}, ui.STATUS_LABELS[status]),
        ui.el('span', { class: 'kanban-count' }, String(tasks.length)),
      ]),
      canCreate ? ui.el('button', {
        class: 'kanban-add-btn',
        title: 'Додати завдання в цю колонку',
        onclick: (e) => {
          e.stopPropagation();
          tasksView.openTaskForm({ status });
        },
      }, '+') : null,
    ]);
    col.append(head);

    const body = ui.el('div', { class: 'kanban-body' });
    if (!tasks.length) {
      body.append(ui.el('div', { class: 'kanban-empty' }, 'Перетягніть сюди'));
    } else {
      tasks.forEach(t => body.append(this.card(t)));
    }
    col.append(body);
    return col;
  },

  card(t) {
    const overdue = ui.isOverdue(t.deadline, t.status);
    const tags = (t.tags || '').split(',').map(s => s.trim()).filter(Boolean).slice(0, 2);

    const c = ui.el('div', {
      class: `kanban-card priority-${t.priority}` + (overdue ? ' is-overdue' : ''),
      draggable: 'true',
      ondragstart: (e) => {
        e.dataTransfer.setData('task-id', t.id);
        c.classList.add('dragging');
      },
      ondragend: () => c.classList.remove('dragging'),
      onclick: () => tasksView.openTaskDetail(t.id),
    }, [
      ui.el('div', { class: 'kc-head' }, [
        ui.badge('priority', t.priority),
        ui.el('span', { class: 'kc-id' }, '#' + t.id),
      ]),
      ui.el('div', { class: 'kc-title' }, t.title),
      tags.length ? ui.el('div', { class: 'kc-tags' },
        tags.map(tag => ui.el('span', { class: 'kc-tag' }, '#' + tag))
      ) : null,
      ui.el('div', { class: 'kc-foot' }, [
        ui.avatar(t.assignee_name, 24),
        ui.el('div', { class: 'kc-meta' }, [
          t.comment_count ? ui.el('span', { class: 'kc-icon' }, `💬 ${t.comment_count}`) : null,
          t.deadline ? ui.el('span', {
            class: 'kc-deadline' + (overdue ? ' overdue' : ''),
          }, '📅 ' + ui.deadlineLabel(t.deadline, t.status)) : null,
        ]),
      ]),
    ]);
    return c;
  },
};
