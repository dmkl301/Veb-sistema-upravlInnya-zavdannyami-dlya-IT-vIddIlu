const usersView = {
  async render(root) {
    const me = JSON.parse(localStorage.getItem('user') || '{}');
    if (me.role !== 'admin') {
      root.innerHTML = '<div class="empty">Доступ дозволено лише адміністраторам</div>';
      return;
    }
    root.innerHTML = '<div class="empty">Завантаження…</div>';
    try {
      const users = await api.get('/users');
      root.innerHTML = '';
      root.append(
        ui.el('div', { class: 'view-header' }, [
          ui.el('h2', {}, 'Користувачі'),
          ui.el('div', { class: 'view-actions' }, [
            ui.el('button', {
              class: 'btn btn-primary',
              onclick: () => this.openForm(),
            }, '+ Новий користувач'),
          ]),
        ]),
        this.table(users, me)
      );
    } catch (e) {
      root.innerHTML = `<div class="empty">${e.message}</div>`;
    }
  },

  table(users, me) {
    const tbl = ui.el('table', { class: 'table' });
    const thead = ui.el('thead', {}, ui.el('tr', {}, [
      ui.el('th', {}, 'Логін'),
      ui.el('th', {}, 'Ім\'я'),
      ui.el('th', {}, 'Роль'),
      ui.el('th', {}, 'Відділ'),
      ui.el('th', {}, 'Створено'),
      ui.el('th', {}, ''),
    ]));
    const tbody = ui.el('tbody');
    users.forEach(u => {
      const actions = ui.el('div', { style: 'display:flex; gap:6px; justify-content:flex-end' }, [
        ui.el('button', { class: 'btn btn-ghost btn-sm', onclick: () => this.openForm(u) }, 'Редаг.'),
        u.id !== me.id ? ui.el('button', {
          class: 'btn btn-danger btn-sm',
          onclick: async () => {
            if (!confirm(`Видалити користувача ${u.username}?`)) return;
            try {
              await api.del('/users/' + u.id);
              ui.toast('Користувача видалено', 'success');
              this.render(document.getElementById('view-root'));
            } catch (e) { ui.toast(e.message, 'error'); }
          },
        }, 'Видал.') : null,
      ]);
      tbody.append(ui.el('tr', {}, [
        ui.el('td', {}, u.username),
        ui.el('td', {}, u.full_name),
        ui.el('td', {}, [ui.badge('role', u.role)]),
        ui.el('td', {}, u.department || '—'),
        ui.el('td', {}, ui.formatDateTime(u.created_at)),
        ui.el('td', {}, [actions]),
      ]));
    });
    tbl.append(thead, tbody);
    return tbl;
  },

  openForm(user = null) {
    const isEdit = !!user;
    const f = ui.el('form');
    const inputs = {
      username: ui.el('input', { type: 'text', name: 'username', required: !isEdit, value: user?.username || '', disabled: isEdit ? 'disabled' : null }),
      password: ui.el('input', { type: 'password', name: 'password', placeholder: isEdit ? 'Залиште порожнім, щоб не змінювати' : '' }),
      full_name: ui.el('input', { type: 'text', name: 'full_name', required: true, value: user?.full_name || '' }),
      role: ui.el('select', { name: 'role' }),
      department: ui.el('input', { type: 'text', name: 'department', value: user?.department || '' }),
    };
    Object.entries(ui.ROLE_LABELS).forEach(([v, l]) => {
      const o = ui.el('option', { value: v }, l);
      if (user?.role === v || (!user && v === 'employee')) o.selected = true;
      inputs.role.append(o);
    });

    f.append(
      ui.el('label', {}, [ui.el('span', {}, 'Логін *'), inputs.username]),
      ui.el('label', {}, [ui.el('span', {}, isEdit ? 'Новий пароль' : 'Пароль *'), inputs.password]),
      ui.el('label', {}, [ui.el('span', {}, 'Повне ім\'я *'), inputs.full_name]),
      ui.el('div', { class: 'row' }, [
        ui.el('label', {}, [ui.el('span', {}, 'Роль'), inputs.role]),
        ui.el('label', {}, [ui.el('span', {}, 'Відділ'), inputs.department]),
      ]),
    );

    const submit = ui.el('button', { type: 'submit', class: 'btn btn-primary' }, isEdit ? 'Зберегти' : 'Створити');
    const cancel = ui.el('button', { type: 'button', class: 'btn btn-ghost', onclick: () => modal.close() }, 'Скасувати');

    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(f));
      if (isEdit && !data.password) delete data.password;
      try {
        if (isEdit) {
          await api.put('/users/' + user.id, data);
          ui.toast('Збережено', 'success');
        } else {
          await api.post('/users', data);
          ui.toast('Користувача створено', 'success');
        }
        modal.close();
        this.render(document.getElementById('view-root'));
      } catch (err) { ui.toast(err.message, 'error'); }
    });

    const modal = ui.modal({
      title: isEdit ? `Редагування: ${user.username}` : 'Новий користувач',
      body: f,
      footer: [cancel, submit],
    });
  },
};
