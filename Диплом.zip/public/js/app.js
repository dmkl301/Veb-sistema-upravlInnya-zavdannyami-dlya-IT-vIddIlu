(async function init() {
  const token = localStorage.getItem('token');
  if (!token) { location.href = '/'; return; }

  let me;
  try {
    me = await api.get('/auth/me');
    localStorage.setItem('user', JSON.stringify(me));
  } catch {
    location.href = '/';
    return;
  }

  document.getElementById('current-user').textContent = `${me.full_name} · ${ui.ROLE_LABELS[me.role]}`;

  document.querySelectorAll('[data-admin]').forEach(el => {
    if (me.role !== 'admin') el.classList.add('hidden');
  });

  const root = document.getElementById('view-root');
  const navBtns = document.querySelectorAll('.nav-btn');

  const VIEWS = {
    dashboard: dashboardView,
    tasks: tasksView,
    kanban: kanbanView,
    users: usersView,
  };

  function showView(name) {
    if (!VIEWS[name]) name = 'dashboard';
    navBtns.forEach(b => b.classList.toggle('active', b.dataset.view === name));
    location.hash = name;
    VIEWS[name].render(root);
  }

  navBtns.forEach(b => b.addEventListener('click', () => showView(b.dataset.view)));

  document.getElementById('logout-btn').addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    location.href = '/';
  });

  const initial = (location.hash || '#dashboard').slice(1);
  showView(initial);
})();
