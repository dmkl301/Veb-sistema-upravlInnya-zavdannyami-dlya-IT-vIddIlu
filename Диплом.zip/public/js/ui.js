const ui = {
  STATUS_LABELS: {
    todo: 'До виконання',
    in_progress: 'В роботі',
    review: 'Перевірка',
    done: 'Завершено',
  },
  PRIORITY_LABELS: {
    low: 'Низький',
    medium: 'Середній',
    high: 'Високий',
    critical: 'Критичний',
  },
  ROLE_LABELS: {
    admin: 'Адмін',
    manager: 'Менеджер',
    employee: 'Виконавець',
  },

  el(tag, attrs = {}, children = []) {
    const e = document.createElement(tag);
    for (const k in attrs) {
      if (k === 'class') e.className = attrs[k];
      else if (k === 'html') e.innerHTML = attrs[k];
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), attrs[k]);
      else if (k === 'dataset') Object.assign(e.dataset, attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (Array.isArray(children) ? children : [children]).forEach(c => {
      if (c == null || c === false) return;
      e.append(c.nodeType ? c : document.createTextNode(String(c)));
    });
    return e;
  },

  formatDate(s) {
    if (!s) return '—';
    const d = new Date(s.length <= 10 ? s + 'T00:00:00' : s);
    return d.toLocaleDateString('uk-UA');
  },

  formatDateTime(s) {
    if (!s) return '—';
    const d = new Date(s.replace(' ', 'T') + 'Z');
    return d.toLocaleString('uk-UA');
  },

  isOverdue(deadline, status) {
    if (!deadline || status === 'done') return false;
    return new Date(deadline) < new Date(new Date().toDateString());
  },

  toast(msg, type = '') {
    const t = ui.el('div', { class: `toast ${type}` }, msg);
    document.body.append(t);
    setTimeout(() => t.remove(), 3000);
  },

  modal({ title, body, footer, onClose }) {
    const root = document.getElementById('modal-root');
    const close = () => { root.innerHTML = ''; if (onClose) onClose(); };
    const backdrop = ui.el('div', {
      class: 'modal-backdrop',
      onclick: (e) => { if (e.target === backdrop) close(); }
    });
    const modal = ui.el('div', { class: 'modal' });
    const head = ui.el('div', { class: 'modal-header' }, [
      ui.el('h3', {}, title),
      ui.el('button', { class: 'close-btn', onclick: close }, '×'),
    ]);
    const bodyEl = ui.el('div', { class: 'modal-body' });
    if (typeof body === 'string') bodyEl.innerHTML = body;
    else if (body) bodyEl.append(body);
    modal.append(head, bodyEl);
    if (footer) {
      const f = ui.el('div', { class: 'modal-footer' });
      footer.forEach(b => f.append(b));
      modal.append(f);
    }
    backdrop.append(modal);
    root.innerHTML = '';
    root.append(backdrop);
    return { close };
  },

  avatar(name, size = 28) {
    if (!name) {
      return ui.el('div', {
        class: 'avatar avatar-empty',
        style: `width:${size}px;height:${size}px;font-size:${Math.round(size * 0.45)}px`,
        title: 'Не призначено',
      }, '?');
    }
    const parts = name.trim().split(/\s+/);
    const initials = (parts[0][0] + (parts[1]?.[0] || '')).toUpperCase();
    const colors = ['#4f46e5', '#0891b2', '#059669', '#d97706', '#dc2626', '#7c3aed', '#db2777', '#0284c7'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
    const color = colors[hash % colors.length];
    return ui.el('div', {
      class: 'avatar',
      style: `width:${size}px;height:${size}px;font-size:${Math.round(size * 0.4)}px;background:${color}`,
      title: name,
    }, initials);
  },

  daysUntil(deadline) {
    if (!deadline) return null;
    const today = new Date(new Date().toDateString());
    const d = new Date(deadline + 'T00:00:00');
    return Math.round((d - today) / 86400000);
  },

  deadlineLabel(deadline, status) {
    if (!deadline) return '';
    if (status === 'done') return ui.formatDate(deadline);
    const days = ui.daysUntil(deadline);
    if (days < 0) return `Прострочено на ${Math.abs(days)} дн.`;
    if (days === 0) return 'Сьогодні';
    if (days === 1) return 'Завтра';
    if (days <= 7) return `Через ${days} дн.`;
    return ui.formatDate(deadline);
  },

  badge(type, value) {
    const cls = type === 'priority'
      ? `priority-badge priority-${value}`
      : type === 'status'
        ? `status-badge status-${value}`
        : `role-badge role-${value}`;
    const label = type === 'priority' ? ui.PRIORITY_LABELS[value]
      : type === 'status' ? ui.STATUS_LABELS[value]
      : ui.ROLE_LABELS[value];
    return ui.el('span', { class: cls }, label);
  },
};
