const dashboardView = {
  charts: {},

  PALETTE: {
    todo: '#9ca3af',
    in_progress: '#f59e0b',
    review: '#8b5cf6',
    done: '#10b981',
    low: '#94a3b8',
    medium: '#3b82f6',
    high: '#f97316',
    critical: '#ef4444',
  },

  async render(root) {
    root.innerHTML = '<div class="empty">Завантаження…</div>';
    Object.values(this.charts).forEach(c => c && c.destroy && c.destroy());
    this.charts = {};
    try {
      const stats = await api.get('/tasks/stats');
      const all = await api.get('/tasks');
      root.innerHTML = '';
      root.append(this.build(stats, all));
      this.drawCharts(stats);
    } catch (e) {
      root.innerHTML = `<div class="empty">${e.message}</div>`;
    }
  },

  build(stats, all) {
    const wrap = document.createDocumentFragment();
    wrap.append(ui.el('div', { class: 'view-header' }, [ui.el('h2', {}, '📊 Дашборд')]));

    const doneCount = (stats.byStatus.find(s => s.status === 'done') || { c: 0 }).c;
    const completionRate = stats.total ? Math.round(doneCount / stats.total * 100) : 0;

    const totals = ui.el('div', { class: 'stats-grid' }, [
      this.statCard('info', '📋', 'Усього завдань', stats.total),
      this.statCard('warning', '⚡', 'Мої активні', stats.myOpen),
      this.statCard('danger', '🔥', 'Прострочені', stats.overdue),
      this.statCard('success', '✅', `Виконано (${completionRate}%)`, doneCount),
    ]);
    wrap.append(totals);

    const grid = ui.el('div', { class: 'charts-grid' }, [
      this.chartCard('chart-status', 'Розподіл за статусом', 'doughnut'),
      this.chartCard('chart-priority', 'Розподіл за пріоритетом', 'pie'),
    ]);
    wrap.append(grid);

    wrap.append(this.chartCard('chart-timeline', 'Динаміка за 14 днів', 'line', 'wide'));

    if (stats.byAssignee && stats.byAssignee.length) {
      wrap.append(this.chartCard('chart-assignees', 'Завдання по виконавцях', 'bar', 'wide'));
    }

    const recentCard = ui.el('div', { class: 'card' });
    recentCard.append(ui.el('h3', {}, '🕐 Останні завдання'));
    if (!all.length) {
      recentCard.append(ui.el('div', { class: 'empty' }, 'Завдань ще немає'));
    } else {
      const list = ui.el('div', { class: 'task-list' });
      all.slice(0, 6).forEach(t => list.append(tasksView.taskRow(t)));
      recentCard.append(list);
    }
    wrap.append(recentCard);

    return wrap;
  },

  statCard(type, icon, label, value) {
    return ui.el('div', { class: `stat-card ${type}` }, [
      ui.el('div', { class: 'stat-icon' }, icon),
      ui.el('div', { class: 'stat-body' }, [
        ui.el('div', { class: 'stat-label' }, label),
        ui.el('div', { class: 'stat-value' }, String(value)),
      ]),
    ]);
  },

  chartCard(canvasId, title, type, mod = '') {
    const card = ui.el('div', { class: 'card chart-card ' + mod });
    card.append(ui.el('h3', {}, title));
    const canvasWrap = ui.el('div', { class: 'chart-wrap ' + (type === 'doughnut' || type === 'pie' ? 'chart-circle' : '') });
    canvasWrap.append(ui.el('canvas', { id: canvasId }));
    card.append(canvasWrap);
    return card;
  },

  drawCharts(stats) {
    const statusOrder = ['todo', 'in_progress', 'review', 'done'];
    const statusMap = Object.fromEntries(stats.byStatus.map(s => [s.status, s.c]));
    this.charts.status = new Chart(document.getElementById('chart-status'), {
      type: 'doughnut',
      data: {
        labels: statusOrder.map(s => ui.STATUS_LABELS[s]),
        datasets: [{
          data: statusOrder.map(s => statusMap[s] || 0),
          backgroundColor: statusOrder.map(s => this.PALETTE[s]),
          borderWidth: 2,
          borderColor: '#fff',
        }],
      },
      options: this.commonOpts({ legend: 'right' }),
    });

    const prioOrder = ['critical', 'high', 'medium', 'low'];
    const prioMap = Object.fromEntries(stats.byPriority.map(p => [p.priority, p.c]));
    this.charts.priority = new Chart(document.getElementById('chart-priority'), {
      type: 'pie',
      data: {
        labels: prioOrder.map(p => ui.PRIORITY_LABELS[p]),
        datasets: [{
          data: prioOrder.map(p => prioMap[p] || 0),
          backgroundColor: prioOrder.map(p => this.PALETTE[p]),
          borderWidth: 2,
          borderColor: '#fff',
        }],
      },
      options: this.commonOpts({ legend: 'right' }),
    });

    if (stats.timeline) {
      const labels = stats.timeline.map(d => {
        const dt = new Date(d.date + 'T00:00:00');
        return dt.toLocaleDateString('uk-UA', { day: '2-digit', month: '2-digit' });
      });
      this.charts.timeline = new Chart(document.getElementById('chart-timeline'), {
        type: 'line',
        data: {
          labels,
          datasets: [
            {
              label: 'Створено',
              data: stats.timeline.map(d => d.created),
              borderColor: '#4f46e5',
              backgroundColor: 'rgba(79,70,229,0.1)',
              tension: 0.3,
              fill: true,
            },
            {
              label: 'Завершено',
              data: stats.timeline.map(d => d.done),
              borderColor: '#10b981',
              backgroundColor: 'rgba(16,185,129,0.1)',
              tension: 0.3,
              fill: true,
            },
          ],
        },
        options: this.commonOpts({
          legend: 'top',
          scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
        }),
      });
    }

    if (stats.byAssignee && stats.byAssignee.length && document.getElementById('chart-assignees')) {
      this.charts.assignees = new Chart(document.getElementById('chart-assignees'), {
        type: 'bar',
        data: {
          labels: stats.byAssignee.map(a => a.name),
          datasets: [
            {
              label: 'Активні',
              data: stats.byAssignee.map(a => a.open_count),
              backgroundColor: '#f59e0b',
            },
            {
              label: 'Завершені',
              data: stats.byAssignee.map(a => a.done_count),
              backgroundColor: '#10b981',
            },
          ],
        },
        options: this.commonOpts({
          legend: 'top',
          scales: {
            x: { stacked: true },
            y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } },
          },
        }),
      });
    }
  },

  commonOpts({ legend = 'top', scales } = {}) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: legend, labels: { font: { size: 12 }, padding: 12 } },
        tooltip: { padding: 10, cornerRadius: 6 },
      },
      ...(scales ? { scales } : {}),
    };
  },
};
