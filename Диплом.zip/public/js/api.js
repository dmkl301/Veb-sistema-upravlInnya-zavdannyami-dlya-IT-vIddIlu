const api = (() => {
  const BASE = '/api';

  async function request(method, url, body, auth = true) {
    const headers = { 'Content-Type': 'application/json' };
    if (auth) {
      const token = localStorage.getItem('token');
      if (token) headers['Authorization'] = `Bearer ${token}`;
    }
    const res = await fetch(BASE + url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch {}
    if (!res.ok) {
      if (res.status === 401 && auth) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        if (location.pathname !== '/' && location.pathname !== '/index.html') {
          location.href = '/';
          return;
        }
      }
      const err = new Error((data && data.error) || `HTTP ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  return {
    get: (url, auth = true) => request('GET', url, null, auth),
    post: (url, body, auth = true) => request('POST', url, body, auth),
    put: (url, body, auth = true) => request('PUT', url, body, auth),
    del: (url, auth = true) => request('DELETE', url, null, auth),
  };
})();
