# IT Task Manager

Веб-система управління завданнями для ІТ-відділу.

## Можливості

- **Автентифікація** з JWT, три ролі: адміністратор, менеджер, виконавець
- **Управління завданнями** (створення, редагування, видалення, фільтри, пошук)
- **Канбан-дошка** з drag&drop переміщенням між колонками
- **Дашборд** зі статистикою (за статусом, пріоритетом, прострочені)
- **Коментарі** до завдань
- **Історія змін** кожного завдання
- **Адмін-панель** для керування користувачами
- Дедлайни з підсвічуванням прострочених
- Теги для категоризації

## Стек

- **Backend:** Node.js + Express + SQLite (better-sqlite3) + JWT + bcrypt
- **Frontend:** Vanilla JS + HTML + CSS (без збирання, без фреймворків)

## Запуск

```bash
npm install
npm start
```

Відкрити в браузері: <http://localhost:3000>

## Тестування

Проєкт містить unit та integration тести (Node.js built-in test runner, без зайвих залежностей).

```bash
npm test
```

**Покриття:**
- `tests/auth.unit.test.js` — JWT, bcrypt, middleware (9 тестів)
- `tests/api.integration.test.js` — повний цикл API: auth, tasks CRUD, comments, users (18 тестів)

Загалом: **27 тестів**.

## Тестові акаунти

| Логін      | Пароль     | Роль          |
|------------|------------|---------------|
| `admin`    | `admin`    | Адміністратор |
| `manager`  | `manager`  | Менеджер      |
| `employee` | `employee` | Виконавець    |
| `anna`     | `anna123`  | Виконавець    |

## Права за ролями

| Дія                            | Адмін | Менеджер | Виконавець |
|--------------------------------|:-----:|:--------:|:----------:|
| Перегляд завдань               | ✅    | ✅       | ✅         |
| Створення завдань              | ✅    | ✅       | ❌         |
| Редагування своїх завдань      | ✅    | ✅       | ✅ (тільки статус)  |
| Видалення завдань              | ✅    | ✅ (свої)| ❌         |
| Зміна виконавця/пріоритету     | ✅    | ✅       | ❌         |
| Управління користувачами       | ✅    | ❌       | ❌         |

## Структура проєкту

```
project/
├── server/
│   ├── index.js          # точка входу Express
│   ├── db.js             # ініціалізація SQLite + сіди
│   ├── auth.js           # JWT middleware
│   └── routes/
│       ├── auth.js       # /api/auth/*
│       ├── users.js      # /api/users/*
│       ├── tasks.js      # /api/tasks/*
│       └── comments.js   # /api/tasks/:id/comments
├── public/
│   ├── index.html        # сторінка входу
│   ├── app.html          # SPA-каркас
│   ├── css/styles.css
│   └── js/
│       ├── api.js        # HTTP-клієнт
│       ├── ui.js         # утиліти DOM
│       ├── app.js        # роутер видів
│       ├── dashboard.js
│       ├── tasks.js
│       ├── kanban.js
│       └── users.js
├── data/                 # SQLite-база (створюється автоматично)
└── package.json
```

## API (короткий довідник)

```
POST   /api/auth/login                   # { username, password } → { token, user }
GET    /api/auth/me                      # поточний користувач

GET    /api/users                        # список (всі авторизовані)
POST   /api/users                        # створити (admin)
PUT    /api/users/:id                    # оновити (admin)
DELETE /api/users/:id                    # видалити (admin)

GET    /api/tasks?status=&priority=&assignee_id=&q=&mine=1
GET    /api/tasks/stats
GET    /api/tasks/:id
POST   /api/tasks                        # створити (admin/manager)
PUT    /api/tasks/:id                    # оновити (за правами)
DELETE /api/tasks/:id

GET    /api/tasks/:id/comments
POST   /api/tasks/:id/comments
DELETE /api/tasks/:taskId/comments/:commentId

GET    /api/tasks/:id/history
```

Усі запити (крім `/api/auth/login`) вимагають заголовок `Authorization: Bearer <token>`.

## Налаштування

- `PORT` — порт сервера (за замовч. `3000`)
- `JWT_SECRET` — секрет для JWT (для production обов'язково задайте)

```bash
PORT=8080 JWT_SECRET=my-strong-secret npm start
```

## Скидання бази

База лежить у `data/app.sqlite`. Щоб скинути дані з нуля:

```bash
rm -rf data
npm start
```
